package kr.co.sist.cinema.post.manager;

public class BannedWord {
	
	private String content;
	private String serialNum;
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
	
}
